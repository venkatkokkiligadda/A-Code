import React from 'react'

const Header = (props) => {
  return (
    <div className='jumbotron jumbotron-fluid header'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-6'><h1>{props.header}</h1></div>
          <div className='col-md-6 help-text'>
            <h3 className='pull-right spacing-style'>Need Help <i className='fa fa-comments icon-size' /></h3>
            <h3 className='pull-right spacing-style'>Need Help <i className='fa fa-question-circle icon-size' /></h3>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Header

import React, { Component } from 'react'
import '../css/style.css'
import Error from '../components/Error'
import SecondaryHeader from './SecondaryHeader'
import { Link } from 'react-router-dom'

class CreateNewPwd extends Component {
  constructor (props) {
    super(props)
    this.state = {
      pwd: '',
      rePwd: '',
      error: false,
      validSubmit: false
    }
    this.handlePasswordInput = this.handlePasswordInput.bind(this)
    this.handleReenteredPassword = this.handleReenteredPassword.bind(this)
    this.handleSubmit = this.handleSubmit.bind(this)
  }

  handlePasswordInput (event) {
    this.setState({ pwd: event.target.value })
  }

  handleReenteredPassword (event) {
    this.setState({ repwd: event.target.value })
  }

  handleSubmit (event) {
    if (this.validatePasswordMatch(this.state.pwd, this.state.repwd)) {
      this.setState({ validSubmit: true })
      this.props.history.push('/pwdoptions')
    } else {
      this.setState({ error: true })
    }
    this.setState({
      pwd: '',
      repwd: ''
    })
    event.preventDefault()
  }

  validatePasswordMatch (pwd, reEnteredpwd) {
    if (pwd === reEnteredpwd) return false
    return false
  }

  render () {
    return (
      <div>
        <div className='container'>
          {this.state.error ? <Error title='Error :' desc='Please fill out the required form' /> : <span />}
          <SecondaryHeader header='Create New Password' isRequiredShow />
          <div className='container-fluid'>
            <form onSubmit={this.handleSubmit} className='container inline-label'>
              <div className='container'>
                <div className='row'>
                  <div className='col-md-9'>
                    <div>
                      <div className='form-group row'>
                        <div className='col-md-4'><label>Choose a New Password: </label></div>
                        <div className='col-md-6'><input type='text' className='form-control' onChange={this.handlePasswordInput} placeholder='Enter new Password' /></div>
                        <div className='col-md-2 align-top-padding'><i className='fa fa-eye-slash' /></div>
                      </div>
                      <div className='form-group row'>
                        <div className='col-md-4'><label>Re-enter New Password: </label></div>
                        <div className='col-md-6'><input type='text' className='form-control' onChange={this.handleReenteredPassword} placeholder='Re-enter New Password' /></div>
                        <div className='col-md-2 align-top-padding'><i className='fa fa-eye-slash' /></div>
                      </div>
                    </div>
                  </div>
                  <div className='col-md-3'>
                    <div className='card'>
                      <div className='card-body'>
                        <h5 className='card-title'>Password Guidelines</h5>
                        <hr />
                        <small>
                          <p className='card-text text-muted'>
                            <span>Eg. MY@password2233</span> <br /><br />
                            <span>Must be 6-15 characters</span><br />
                            <span>Acceptable characters A-Z, a-z, 0-9, @, _, -, ., $, #</span><br />
                            <span>Must contain atleast one letter</span><br />
                            <span>Must contain atleast one number</span><br />
                            <span>Cannot contain empty spaces</span><br />
                            <span>Cannot be the same as your UserId</span><br />
                          </p>
                        </small>
                      </div>
                    </div>
                  </div>
                </div>
                          </div>
              <div className='btn-style'>
                <div className='pull-left'><Link to='/emailverification'><button type='button' className='btn btn-outline-primary'>Back</button></Link></div>
                <div className='pull-right'><Link to='/pwdupdated'><button type='submit' className='btn btn-primary'>Continue</button></Link></div>
              </div>
            </form>

          </div>
        </div>
      </div>
    )
  }
}

export default CreateNewPwd

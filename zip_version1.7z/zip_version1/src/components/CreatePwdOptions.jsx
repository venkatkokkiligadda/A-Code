import React, { Component } from 'react'
import '../css/style.css'
import Header from '../components/Header'
import Error from '../components/Error'
import SecondaryHeader from './SecondaryHeader'
import { Link } from 'react-router-dom'

class CreatePwdOptions extends Component {
  constructor (props) {
    super(props)
    this.state = {
    }
  }

  render () {
    return (
      <div>
        <Header header='Create New Password' />
        <div className='container'>
          {this.state.error ? <Error title='Error :' desc='Please fill out the required form' /> : <span />}
          <SecondaryHeader header='Choose the way you want to receive your password code' />
          <div className='container-fluid'>
            <form onSubmit={this.handleSubmit} className='container'>
              <div className='row inner-div-padding'>
                <div className='form-check col-md-6'>
                  <div>
                    <input className='form-check-input' type='radio' name='inlineRadioOptions' id='inlineRadio1' value='option1' />
                    <label className='form-check-label'>Email</label>
                  </div>
                  <div className='flex-display inner-div-padding'>
                    <div className='align-top-padding'><i className='fas fa-envelope icon-size default-icon-style ' /></div>
                    <div className='align-side-padding'>
                      <input type='text' className='form-control' id='dateOfBirth' onChange={this.handleDateChange} placeholder='Enter date of birth' />
                    </div>
                  </div>
                  <div className='text-muted'>Get a code via email and enter it on the next scrteen. Choose the correct email from the drop-down menu.</div>
                </div>
                <div className='form-check col-md-6'>
                  <div>
                    <input className='form-check-input' type='radio' name='inlineRadioOptions' id='inlineRadio1' value='option1' />
                    <label className='form-check-label'>Security Questions</label>
                  </div>
                  <div className='flex-display inner-div-padding'>
                    <div className='align-top-padding'><i className='fa fa-question-circle icon-size default-icon-style ' /></div>
                    <div className='align-side-padding text-muted'>Use your Hints and Responses</div>
                  </div>
                  <div className='text-muted'>Answer a few security questions you made up when you set your account.</div>
                </div>
              </div>
              <div className='btn-style'>
                <div className='pull-left'><Link to='/'><button type='button' className='btn btn-outline-primary'>Back</button></Link></div>
                <div className='pull-right'><Link to='/emailverification'><button type='submit' className='btn btn-primary'>Continue</button></Link></div>
              </div>
            </form>
          </div>
        </div>
      </div>
    )
  }
}

export default CreatePwdOptions

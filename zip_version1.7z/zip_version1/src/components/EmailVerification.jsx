import React, { Component } from 'react'
import '../css/style.css'
import Header from '../components/Header'
import Error from '../components/Error'
import SecondaryHeader from './SecondaryHeader'
import { Link } from 'react-router-dom'

class EmailVerification extends Component {
  constructor (props) {
    super(props)
    this.state = {
    }
  }

  render () {
    return (
      <div>
        <Header header='Email Verification' />
        <div className='container'>
          {this.state.error ? <Error title='' desc='Oops! It looks like you typed the code incorrectly. Please check it and try again. You may want to copy and paste it.' /> : <span />}
          <SecondaryHeader header='Enter your Verification Code' isRequiredShow />
          <div className='container-fluid'>
            <div className='text-muted inner-header'>We just sent you a verification code to email: abcd@gmail.com. Plaese enter the code below and click on continue to create a new password in the next screen. If you don't see our email, be sure to check your spam floder too.</div>
            <form onSubmit={this.handleSubmit} className='container inline-label'>
              <div className='form-group row'>
                <div className='col-md-3'><label>Enter code from sent Email: </label></div>
                <div className='col-md-5'><input type='text' className='form-control' placeholder='Enter verification code' /></div>
                <div className='col-md-4 align-top-padding'>
                  <div className='text-muted'>Didn't receive the code yet ?</div>
                  <a href='#' >Send me a new code</a></div>
              </div>
              <div className='btn-style'>
                <div className='pull-right'><Link to='/newpwd'><button type='submit' className='btn btn-primary'>Continue</button></Link></div>
              </div>
            </form>
          </div>
        </div>
      </div>
    )
  }
}

export default EmailVerification

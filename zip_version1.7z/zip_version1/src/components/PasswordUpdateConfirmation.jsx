import React, { Component } from 'react'
import '../css/style.css'
import Header from '../components/Header'
import SecondaryHeader from './SecondaryHeader'
import { Link } from 'react-router-dom'

class PasswordUpdateConfirmation extends Component {
  constructor (props) {
    super(props)
    this.state = {
    }
  }

  render () {
    return (
      <div>
        <Header header='Forget Your Password' />
        <div className='container'>
          <SecondaryHeader header='Confirmation' />
          <div className='container-fluid'>
            <div className='text-muted inner-header'>Your password has been successfully changed.</div>
            <Link to='/'><button className='btn btn-success'>Member Login</button></Link>
          </div>
        </div>
      </div>
    )
  }
}

export default PasswordUpdateConfirmation

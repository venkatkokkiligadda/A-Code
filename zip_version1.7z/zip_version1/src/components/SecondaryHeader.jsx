import React from 'react'

const SecondaryHeader = (props) => {
  return (
    <div className='secondary-header'>
      <h2>{props.header}</h2>
      <hr />
      {props.isRequiredShow ? <div className='text-right'><small className='text-muted'>*All fields are required.</small></div> : <span />}
    </div>
  )
}

export default SecondaryHeader

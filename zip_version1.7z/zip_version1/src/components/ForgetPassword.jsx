import React, { Component } from 'react'
// import { Link } from 'react-router-dom'
import '../css/style.css'
import Header from '../components/Header'
import Error from '../components/Error'
import SecondaryHeader from './SecondaryHeader'
// import {browserHistory} from 'react-router'

class ForgetPassword extends Component {
  constructor (props) {
    super(props)
    this.state = {
      email: '',
      dob: '',
      error: false,
      validSubmit: false
    }
    this.handleEmailChange = this.handleEmailChange.bind(this)
    this.handleDateChange = this.handleDateChange.bind(this)
    this.handleSubmit = this.handleSubmit.bind(this)
  }
  handleEmailChange (event) {
    this.setState({ email: event.target.value })
  }
  handleDateChange (event) {
    this.setState({ dob: event.target.value })
  }

  handleSubmit (event) {
    if (this.validateEmail(this.state.email) && this.validateDob(this.state.dob)) {
      this.setState({ validSubmit: true })
      this.props.history.push('/pwdoptions')
    } else {
      this.setState({ error: true })
    }
    this.setState({
      email: '',
      dob: ''
    })
    event.preventDefault()
  }
  validateEmail (email) {
    var expression = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}/igm
    return email && expression.test(String(email).toLowerCase())
  }

  validateDob (dob) {
    var expression = /^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/g
    return dob && expression.test(String(dob))
  }

  render () {
    return (
      <div>
        <Header header='Forget Password' />
        <div className='container'>
          {this.state.error ? <Error title='Error :' desc='Please fill out the required form' /> : <span />}
          <SecondaryHeader header='Enter your Personal Information' isRequiredShow />
          <div className='container-fluid'>
            <div className='text-muted inner-header'>Please enter the following information. All fields must match what we have on file.</div>
            <form onSubmit={this.handleSubmit} className='container inline-label'>
              <div className='form-group row'>
                <div className='col-md-3'><label>Email address: </label></div>
                <div className='col-md-5'><input type='email' className='form-control' id='emailInput' onChange={this.handleEmailChange} placeholder='Enter email' /></div>
                <div className='col-md-4 align-top-padding'><a href='#' >Forget your UserID ?</a></div>
              </div>
              <div className='form-group row'>
                <div className='col-md-3'><label>Enter your Date of birth: </label></div>
                <div className='col-md-5'><input type='text' className='form-control' id='dateOfBirth' onChange={this.handleDateChange} placeholder='Enter date of birth' /></div>
                <div className='col-md-4 text-muted align-top-padding'>(mm/dd/yyyy)</div>
              </div>
              <div className='btn-style'>
                <button type='submit' className='btn btn-primary pull-right'>Continue</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    )
  }
}

export default ForgetPassword

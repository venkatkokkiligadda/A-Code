import React, { Component } from 'react'
import ForgetPassword from './components/ForgetPassword'
import CreateNewPwd from './components/CreateNewPwd'
import CreatePwdOptions from './components/CreatePwdOptions'
import EmailVerification from './components/EmailVerification'
import PasswordUpdateConfirmation from './components/PasswordUpdateConfirmation'
import { BrowserRouter, Route } from 'react-router-dom'
import './css/style.css'

class App extends Component {
  render () {
    return (
      <BrowserRouter>
        <div className='app'>
          <Route exact path='/' component={ForgetPassword} />
          <Route path='/pwdoptions' component={CreatePwdOptions} />
          <Route path='/emailverification' component={EmailVerification} />
          <Route path='/newpwd' component={CreateNewPwd} />
          <Route path='/pwdupdated' component={PasswordUpdateConfirmation} />
        </div>
      </BrowserRouter>
    )
  }
}

export default App
